/**
 * Common homeworks test classes
 * of <a href="https://www.kgeorgiy.info/courses/paradigms/">Paradigms of Programming</a> course.
 *
 * @author Georgiy Korneev (kgeorgiy@kgeorgiy.info)
 */
package base;