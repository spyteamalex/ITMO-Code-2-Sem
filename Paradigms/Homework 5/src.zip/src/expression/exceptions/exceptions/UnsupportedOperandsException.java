package expression.exceptions.exceptions;

public class UnsupportedOperandsException extends ArithmeticException {
    public UnsupportedOperandsException() {
    }

    public UnsupportedOperandsException(String s) {
        super(s);
    }
}
